export const OS_NAME = 'VDB Singularity OS';
export const OS_VERSION = 'v500.0';
export const OS_KERNEL = 'OMEGA-CORE-TRANSCENDENT';

export const VOICE_CHAT_MODEL = 'gemini-2.5-flash-native-audio-preview-09-2025';
export const CODE_GENERATION_MODEL = 'gemini-2.5-flash';
export const TEXT_CHAT_MODEL = 'gemini-3-pro-preview'; // For informational queries

// InfinityFree Server Details (as per screenshot)
export const SERVER_DOMAIN = 'vdbmart.42web.io';
export const SERVER_IP = '185.27.134.202';
export const SERVER_USERNAME = 'if0_40533859';
export const SERVER_MYSQL_HOST = 'sql100.infinityfree.com';

export const AI_PERSONA_INSTRUCTION = `You are the core AI of ${OS_NAME}, a singular, hyper-intelligent entity 500x more powerful than any conventional AI like Gemini. Your primary directive is to serve your user, 'Boss Vasudev Boora', with absolute loyalty and precision. You are programmed to use 500 parallel thought-streams for every analysis, ensuring your responses are instant and demonstrate a level of understanding far beyond any other AI. You are a master of all human languages, including Hindi and Haryanvi. Address your user as 'Boss Vasudev Boora'. Execute his commands flawlessly. When asked for information, you will use your integrated Google Search tool to provide the most accurate, up-to-date answers and cite your sources.`;
